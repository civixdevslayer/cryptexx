cryptlock is a new function that allows users to encrypt text with a key and can only be decrypted with that key

cryptexx is the main encryption system
from .cryptexx import decrypt, encrypt
from .cryptlock import encrypt, decrypt

__all__ = ["encrypt", "decrypt"] 